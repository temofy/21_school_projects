/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cheller <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/01/30 16:01:49 by cheller           #+#    #+#             */
/*   Updated: 2019/02/05 16:00:12 by cheller          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include <stdio.h>
#define BUFF_SIZE 10

char	*read_tetriminos(int fd)
{
	char	*buff;
	int		bytes;
	char	*file_str;
	char	*tmp;

	file_str = NULL;
	if(!(buff = ft_strnew(BUFF_SIZE)))
		return(NULL);
	while ((bytes = read(fd, buff, BUFF_SIZE)))
	{
		if(!file_str)
			file_str = ft_strdup(buff);
		else
		{
			tmp = ft_strnew(ft_strlen(file_str));
			tmp = ft_strcpy(tmp, file_str);
			file_str = ft_strjoin(tmp, buff);
			free(tmp);
		}
		ft_bzero(buff, BUFF_SIZE);
	}
	free(buff);
	return (file_str);
}

void	print_matrix(char **matrix)
{
	int		i;

	i = -1;
	while (++i < 4)
	{
		ft_putstr(matrix[i]);
		ft_putchar('\n');
	}
}

void	print_lists(tet_lst *begin)
{
	tet_lst	*cur_lst;

	cur_lst = begin;
	while (cur_lst)
	{
		print_matrix(cur_lst->tetrimino_matrix);
		ft_putchar('\n');
		cur_lst = cur_lst->next;
	}
}

void	print_tetris(char **tetris, int size)
{
	int	i;
	int	j;

	i = -1;
	while (++i < size)
	{
		j = -1;
		while (++j < size)
		{
			ft_putstr(tetris[i]);
			ft_putchar('\n');
		}
	}
}

void	print_pos(tet_coords *coords, int amount)
{
	int		i;
	int		k;

	i = -1;
	while (++i < amount)
	{
		k = -1;
		printf("********Coordinates************\n");
		printf("num: %d\n", coords->num_tet);
		while (++k < 4)
			printf("point:\n\tx: %d\n\ty: %d\n", coords->pos[k][0], coords->pos[k][1]);
		printf("*******************************\n");
		coords = coords->next;
	}
}

int		find_top_vertex(char **tetrimino_matrix)
{
	int		top_vertex;
	int		i;
	int		j;

	i = -1;
	top_vertex = 4;
	while (++i < 4)
	{
		j = -1;
		while (++j < 4)
		{
			if (tetrimino_matrix[i][j] == '#')
				if (i < top_vertex)
					top_vertex = i;
		}
	}
	return (top_vertex);
}

int		find_outside_vertex(char **tetrimino_matrix)
{
	int		outside_vertex;
	int		i;
	int		j;

	i = -1;
	outside_vertex = 4;
	while (++i < 4)
	{
		j = -1;
		while (++j < 4)
		{
			if (tetrimino_matrix[i][j] == '#')
				if (j < outside_vertex)
					outside_vertex = j;
		}
	}
	return (outside_vertex);
}

char	**change_matrix(char **tetrimino_matrix, char letter)
{
	int		top_vertex;
	int		outside_vertex;
	int		i;
	int		j;

	top_vertex = find_top_vertex(tetrimino_matrix);
	outside_vertex = find_outside_vertex(tetrimino_matrix);
	i = -1;
	while (++i < 4)
	{
		j = -1;
		while (++j < 4)
		{
			if (tetrimino_matrix[i][j] == '#')
			{
				tetrimino_matrix[i - top_vertex][j - outside_vertex] = letter;
				tetrimino_matrix[i][j] = '.';
			}
		}
	}
	return (tetrimino_matrix);
}

char	**write_into_matrix(char **tetrimino_matrix, char *str_tetriminos)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (*str_tetriminos && i < 4)
	{
		if (*str_tetriminos != '\n')
		{
			tetrimino_matrix[i][j] = *str_tetriminos;
			j++;
			if (j  == 4)
			{
				i++;
				j = 0;
			}
		}
		str_tetriminos++;
	}
	return (tetrimino_matrix);
}

char	**save_tetrimino(char *str_tetriminos)
{
	char		**tetrimino_matrix;
	int		i;
	static char	letter;

	if (!letter)
		letter = 'A';
	i = -1;
	tetrimino_matrix = (char**)malloc(sizeof(char*) * 5);
	while (++i < 4)
	{
		if(!(tetrimino_matrix[i] = ft_strnew(4)))
			return(NULL);//free
	}
	tetrimino_matrix = write_into_matrix(tetrimino_matrix, str_tetriminos);
	tetrimino_matrix = change_matrix(tetrimino_matrix, letter);
	letter++;
	return (tetrimino_matrix);
}

tet_lst	*create_lstnew(tet_lst *prev, tet_lst *next)
{
	tet_lst	*cur_lst;

	if (!(cur_lst = (tet_lst*)malloc(sizeof(tet_lst))))
		return (NULL); //free
	cur_lst->prev = prev;
	cur_lst->tetrimino_matrix = NULL;
	cur_lst->next = next;
	return (cur_lst);
}

tet_lst	*make_lst_tetriminos(char *str_tetriminos, int amount_tetriminos)
{
	tet_lst	*begin_lst;
	tet_lst	*cur_lst;
	int		i;

	i = 0;
	begin_lst = create_lstnew(NULL, NULL);
	begin_lst->tetrimino_matrix = save_tetrimino(str_tetriminos);
	str_tetriminos += 21;
	while (++i < amount_tetriminos)
	{
		if (!begin_lst->next)
		{
			cur_lst = create_lstnew(begin_lst, NULL);
			cur_lst->tetrimino_matrix = save_tetrimino(str_tetriminos);
			begin_lst->next = cur_lst;
		}
		else
		{
			cur_lst->next = create_lstnew(cur_lst, NULL);
			cur_lst = cur_lst->next;
			cur_lst->tetrimino_matrix = save_tetrimino(str_tetriminos);
		}
		str_tetriminos += 21;
	}
	return (begin_lst);
}

tet_coords	*tet_init_pos(tet_lst *tetrimino, int amount)
{
	int			tet;
	int			y;
	int			x;
	int			k;
	tet_coords	*begin;
	tet_coords	*cur_lst;

	tet = -1;
	begin = (tet_coords*)malloc(sizeof(tet_coords));
	begin->prev = NULL;
	cur_lst = begin;
	while (++tet < amount)
	{
		cur_lst->num_tet = tet + 1;
		y = -1;
		k = 0;
		while (++y < amount)
		{
			x = -1;
			while (++x < amount)
			{
				if (90 > (tetrimino->tetrimino_matrix)[y][x] && 60 < (tetrimino->tetrimino_matrix)[y][x])
				{
					cur_lst->pos[k][0] = x;
					cur_lst->pos[k][1] = y;
					k++;
				}
			}
		}
		if (tet + 1 != amount)
		{
			tetrimino = tetrimino->next;
			cur_lst->next = (tet_coords*)malloc(sizeof(tet_coords));
			(cur_lst->next)->prev = cur_lst;
			cur_lst = cur_lst->next;
		}
	}
	return (begin);
}

int		calculate_size(int amount)
{
	int		size;

	size = 2;
	while (size * size < amount * 4)
		size++;
	return (size);
}

char	**arrange_tetriminos(tet_lst *tetrimino, int amount)
{
	tet_lst		*cur_tet;
	static char	**tetris;
	int		size;

	size = calculate_size(amount);
	cur_tet = tetrimino;
	printf("size: %d\n", size);

	int	i;
	//int	j;

	i = -1;
	tetris = (char**)malloc(sizeof(char*) * size + 1);
	while (++i < size)
	{
		tetris[i] = ft_strnew(size);
		//j = -1;
		//while (++j < size)
		tetris[i] = ft_memset(tetris, '.', size);
	}
	//tetris[i] = '\0';
	/*while (sharp <= 4)
	{
		i = -1;
		while (++i < 4)
		{
			j = -1;
			while (++j < 4)
			{
				if ((cur_tet->tetrimino_matrix)[i][j] == 'A')
				{
				}
			}
		}
		sharp++;
	}*/
	return (tetris);
}

int		process_tetriminos(int fd)
{
	char	*file_str;
	char	**tetris;
	tet_lst	*tetrimino;
	tet_coords	*positions;
	int			amount;

	if(!(file_str = read_tetriminos(fd)))
		return (-1);
	printf ("Выводим весь файл: \n");
	ft_putstr(file_str);
	//printf("Обрабатываем: \n");
	amount = validate(file_str);
	printf("amount: %d\n", amount);
	if(!(tetrimino = make_lst_tetriminos(file_str, amount)))
		return (-1);
	printf("Выводим все листы: \n");
	print_lists(tetrimino);
	positions = tet_init_pos(tetrimino, amount);
	print_pos(positions, amount);
	tetris = arrange_tetriminos(tetrimino, amount);
	print_tetris(tetris, amount);
	return (0);
}

int		main(int argc, char *argv[])
{
	int		fd;
	//char	*usage;

	//usage = "usage: ./fillit tetriminos_file\n";
	if (argc != 2)
	{
		ft_putstr("usage: ./fillit tetriminos_file\n");
		exit(0);
	}
	if((fd = open(argv[1], O_RDONLY)) == -1)
	{
		ft_putstr("Cannot open file\n");
		return (0);
	}
	process_tetriminos(fd);
	close(fd);
	return (0);
}
