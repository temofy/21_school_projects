lem-in_generator
================

lem-in map generator

Build:
make

Usage:
./lem-in_gen [number of ants] [number of nodes]

This program makes naive maps, start and end could not be linked.
